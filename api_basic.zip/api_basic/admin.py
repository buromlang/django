from django.contrib import admin
from api_basic.models import Snippet, AppUser
# Register your models here.


admin.site.register(Snippet)
admin.site.register(AppUser)
